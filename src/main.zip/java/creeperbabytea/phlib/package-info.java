@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault

package creeperbabytea.phlib;

import mcp.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;