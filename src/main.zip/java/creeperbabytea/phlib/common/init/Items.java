package creeperbabytea.phlib.common.init;

import creeperbabytea.phlib.common.PhilosophersObjects;
import creeperbabytea.phlib.common.magic.spellwork.item.ScrollItem;
import creeperbabytea.tealib.common.objects.SingleItemEntry;

public class Items extends net.minecraft.item.Items {
    //public static final SingleItemEntry SCROLL_BAMBOO = PhilosophersObjects.GENERAL.register(new SingleItemEntry(new ScrollItem(ScrollItem.EnumScrollTypes.BAMBOO), "bamboo_scroll", ""));

    public static void init() {
    }
}
