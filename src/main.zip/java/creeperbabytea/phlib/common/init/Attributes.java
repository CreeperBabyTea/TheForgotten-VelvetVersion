package creeperbabytea.phlib.common.init;

import creeperbabytea.phlib.common.PhilosophersObjects;
import creeperbabytea.tealib.common.objects.SingleEntry;
import net.minecraft.entity.ai.attributes.Attribute;

public class Attributes {
    //public static final SingleEntry<Attribute> WAND_OWNER = PhilosophersObjects.GENERAL.register(new )

    public static void init() {
    }
}
