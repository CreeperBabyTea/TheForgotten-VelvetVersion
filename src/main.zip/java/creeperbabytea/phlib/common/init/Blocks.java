package creeperbabytea.phlib.common.init;

public class Blocks {
    public static void init() {
    }
}
