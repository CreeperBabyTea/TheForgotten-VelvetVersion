package creeperbabytea.phlib.common.magic.spellwork.spell;

public enum EnumSpellType implements ISpellType {
    BLESSING,
    CHARM,
    NORMAL,
    HEX,
    CURSE
}
