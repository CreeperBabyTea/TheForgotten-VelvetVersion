package creeperbabytea.phlib.common.magic.spellwork.spell;

public interface ISpellType {
}
