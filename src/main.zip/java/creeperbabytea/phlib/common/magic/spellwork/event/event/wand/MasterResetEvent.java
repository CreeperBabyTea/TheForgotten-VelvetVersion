package creeperbabytea.phlib.common.magic.spellwork.event.event.wand;

import net.minecraft.entity.LivingEntity;

public class MasterResetEvent extends WandEvent {
    public MasterResetEvent(LivingEntity player) {
        super(player);
    }
}
