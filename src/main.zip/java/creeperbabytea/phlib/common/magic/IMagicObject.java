package creeperbabytea.phlib.common.magic;

public interface IMagicObject {
    MagicState getMagicState();
}
