package creeperbabytea.phlib.common.magic.warecraft.item;

import net.minecraft.item.Item;

public class EnchantDictionaryItem extends Item {
    public EnchantDictionaryItem(Properties properties) {
        super(properties);
    }
}
