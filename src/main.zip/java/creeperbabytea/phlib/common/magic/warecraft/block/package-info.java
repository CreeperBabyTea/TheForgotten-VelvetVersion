@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault

package creeperbabytea.phlib.common.magic.warecraft.block;

import mcp.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;