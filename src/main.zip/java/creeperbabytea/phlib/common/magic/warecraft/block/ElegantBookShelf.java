package creeperbabytea.phlib.common.magic.warecraft.block;

import net.minecraft.block.Block;

public class ElegantBookShelf extends Block {
    public ElegantBookShelf(Properties properties) {
        super(properties);
    }
}
