package creeperbabytea.phlib.common.magic.warecraft.item;

public class WareType {
}
