@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault

package creeperbabytea.phlib.common.data;

import mcp.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;