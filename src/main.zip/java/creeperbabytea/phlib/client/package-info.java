@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault

package creeperbabytea.phlib.client;

import mcp.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;