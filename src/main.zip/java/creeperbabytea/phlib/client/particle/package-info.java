@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault

package creeperbabytea.phlib.client.particle;

import mcp.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;