package creeperbabytea.phlib.client.particle;

public class SingleTextureParticle {
}
